# Posit Connect Off-Host Test App

This is a minimal Shiny app designed to test off-host execution on Posit Connect.
Deploy this app via GitHub to your Posit Connect instance.
